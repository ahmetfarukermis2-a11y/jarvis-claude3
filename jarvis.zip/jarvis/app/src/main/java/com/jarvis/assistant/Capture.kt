package com.jarvis.assistant

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.ParcelFileDescriptor
import java.io.OutputStream
import kotlin.math.sqrt

/**
 * Gelişmiş ses motoru (Android 13+): mikrofonu kendimiz açarız, gürültü engelleme / yankı
 * giderme / otomatik kazanç uygularız, düşük frekanslı gürültüyü süzeriz ve sesi bir boru (pipe)
 * ile konuşma tanıyıcıya veririz. Son ~1,5 saniyelik ses ön tamponda tutulur; böylece tanıyıcı
 * yeniden başlarken araya giren boşlukta söylenen kelimeler kaybolmaz.
 */
class Capture {
    companion object {
        const val RATE = 16000
    }

    private class Session(val read: ParcelFileDescriptor, val out: OutputStream) {
        @Volatile var broken = false
    }

    private val effects = ArrayList<AudioEffect>()
    private val ring = ByteArray(RATE * 2 * 3 / 2)
    private var ringPos = 0
    private var ringFilled = 0
    private val lock = Any()

    @Volatile private var running = false
    @Volatile private var session: Session? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 4
            )
        } catch (e: Exception) {
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return false
        }
        val sid = r.audioSessionId
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.let { it.setEnabled(true); effects.add(it) } } catch (_: Exception) {}
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.let { it.setEnabled(true); effects.add(it) } } catch (_: Exception) {}
        try { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.let { it.setEnabled(true); effects.add(it) } } catch (_: Exception) {}
        try {
            r.startRecording()
        } catch (e: Exception) {
            releaseAll(r)
            return false
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            releaseAll(r)
            return false
        }
        running = true
        Thread { loop(r) }.also { it.isDaemon = true }.start()
        return true
    }

    private fun loop(r: AudioRecord) {
        val buf = ShortArray(1600)
        val bytes = ByteArray(3200)
        var prevIn = 0f
        var prevOut = 0f
        var gain = 1f
        while (running) {
            val n = r.read(buf, 0, buf.size)
            if (n < 0) break
            if (n == 0) continue
            var sumSq = 0.0
            for (i in 0 until n) {
                // ~100 Hz yüksek geçiren süzgeç: uğultu, rüzgâr, titreşim gürültüsünü azaltır
                val x = buf[i].toFloat()
                val y = 0.962f * (prevOut + x - prevIn)
                prevIn = x
                prevOut = y
                buf[i] = y.coerceIn(-32768f, 32767f).toInt().toShort()
                sumSq += (y * y).toDouble()
            }
            val rms = sqrt(sumSq / n).toFloat()
            // yumuşak otomatik kazanç: uzaktan/kısık konuşmayı yükseltir (en fazla 4 kat)
            val want = if (rms < 40f) 1f else (2500f / rms).coerceIn(1f, 4f)
            gain += (want - gain) * 0.2f
            for (i in 0 until n) {
                val s = (buf[i] * gain).coerceIn(-32768f, 32767f).toInt()
                bytes[2 * i] = (s and 0xFF).toByte()
                bytes[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
            }
            synchronized(lock) { push(bytes, n * 2) }
            val s = session
            if (s != null && !s.broken) {
                try { s.out.write(bytes, 0, n * 2) } catch (e: Exception) { s.broken = true }
            }
            if (Bus.appVisible) Bus.level.value = Bus.level.value * 0.6f + (rms / 4000f).coerceIn(0f, 1f) * 0.4f
        }
        releaseAll(r)
    }

    private fun push(b: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val n = minOf(len - off, ring.size - ringPos)
            System.arraycopy(b, off, ring, ringPos, n)
            ringPos = (ringPos + n) % ring.size
            off += n
        }
        ringFilled = minOf(ring.size, ringFilled + len)
    }

    /** Yeni bir tanıma oturumu için boru açar; okuma ucunu tanıyıcıya verilecek. Ön tampon başa eklenir. */
    fun openSession(): ParcelFileDescriptor? {
        endSession()
        return try {
            val p = ParcelFileDescriptor.createPipe()
            val out = ParcelFileDescriptor.AutoCloseOutputStream(p[1])
            val s = Session(p[0], out)
            synchronized(lock) {
                val start = (ringPos - ringFilled + ring.size) % ring.size
                val first = minOf(ringFilled, ring.size - start)
                if (ringFilled > 0) {
                    out.write(ring, start, first)
                    if (ringFilled > first) out.write(ring, 0, ringFilled - first)
                }
                session = s
            }
            p[0]
        } catch (e: Exception) {
            null
        }
    }

    fun endSession() {
        val s = session ?: return
        session = null
        try { s.read.close() } catch (_: Exception) {}
        try { s.out.close() } catch (_: Exception) {}
    }

    /** Ön tamponu boşaltır (kendi sesimizin yankısı tanıyıcıya karışmasın). */
    fun clear() {
        synchronized(lock) {
            ringFilled = 0
            ringPos = 0
        }
    }

    fun stop() {
        running = false
        endSession()
    }

    private fun releaseAll(r: AudioRecord) {
        running = false
        for (e in effects) try { e.release() } catch (_: Exception) {}
        effects.clear()
        try { r.stop() } catch (_: Exception) {}
        try { r.release() } catch (_: Exception) {}
    }
}
