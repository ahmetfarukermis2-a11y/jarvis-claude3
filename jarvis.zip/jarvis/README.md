# JARVIS – Türkçe sesli asistan (Android, Kotlin + Jetpack Compose)

> Durum: Kod yazıldı ama **henüz derlenmedi ve cihazda denenmedi.** İlk derlemede küçük hatalar çıkabilir.

## APK nasıl alınır

**A) Telefondan (GitHub ile, bilgisayarsız)**
1. github.com'da ücretsiz hesap aç, yeni bir repo oluştur.
2. Bu klasörün içindekileri repoya yükle (`.github` klasörü dahil).
3. Repoda **Actions** sekmesi → "APK derle" → **Run workflow**.
4. 5–10 dk sonra çalışma bitince **Artifacts → jarvis-apk** dosyasını indir, zip'ten çıkan `app-debug.apk`'yı kur (bilinmeyen kaynaklardan kuruluma izin ver).

**B) Bilgisayarda:** Android Studio ile klasörü aç → Build → Build APK(s).

## Kullanım
- Başlat'a bas, mikrofon iznini ver. "JARVIS" de, "Buyurun efendim" deyince komutu söyle (ya da tek seferde: "JARVIS, saat kaç?").
- Komutlar: saat, hava durumu, fener aç/kapat, YouTube/Spotify/ayarlar aç, pil, alarm kur ("alarm kur 7 30"), ses artır/azalt, sohbet, uyku modu, kendini kapat.
- Kapatma/uyku: "JARVIS uyku modu" mikrofonu kapatır (bildirimden "Uyandır"); "kendini kapat" servisi tamamen durdurur.

## Üç yapay zekâ: JARVIS, FRIDAY, ULTRON
- Adını söylediğin cevap verir ("Friday, hava nasıl?"). Ana ekrandaki üst düğmelerden de seçebilirsin.
- Her birinin kendi kişiliği (istemi), hitabı (efendim / patron / yaratıcım), ses tonu ve rengi var. Ultron yalnızca üslupta alaycı ve soğuktur; gerçekte zarar vermez, komutları yerine getirir.
- Yerleşik komutlar (saat, fener, alarm...) önce çalışır. Uymayan her şey yapay zekâya gider; yapay zekâ kendi kararıyla fener, alarm, hava, saat, pil, ses, YouTube/Spotify/ayarlar gibi eylemlerden birini seçip çalıştırabilir.
- **Dürüst not:** Üçü de aynı yapay zekâ servisini (ücretsiz servis ya da senin ChatGPT anahtarın) kullanır; fark kişilik, ses tonu ve davranıştadır. Telefonda çalışan bağımsız bir model yok. Filmdeki sesleri taklit edemez; tek Türkçe ses, perde ve hız ile değiştirilir. Ücretsiz servis Türkçede ve JSON eylemlerinde zayıf kalabilir; sağlam sonuç için ChatGPT anahtarı ekle.

## Ses tanıma ve gürültü engelleme
- "Gelişmiş ses motoru" (Android 13+): mikrofonu uygulama açar; gürültü engelleme, yankı giderme, kazanç ve ~100 Hz süzgeç uygular; son 1,5 saniyeyi tamponlar, böylece tanıyıcı yeniden başlarken kelime kaçmaz. Deneyseldir: Google'ın tanıyıcısı bu işlenmiş sesi kabul etmezse ya da tanıma kötüleşirse Ayarlar'dan kapat.
- Ana ekranda "SES MOTORU: GELİŞMİŞ/NORMAL" yazar; dalga halkası mikrofon seviyesine tepki verir.

## Bilmen gerekenler (Android sınırları)
- **Ekran kapalıyken dinleme garanti değil.** Ayarlardan açabilirsin ama Redmi/HyperOS pil yönetimi servisi öldürebilir: Uygulama ayarları → Pil → "Kısıtlama yok" ve "Otomatik başlat" aç.
- **Telefon yeniden başlayınca otomatik çalışmaz** (Android 14+ mikrofon servisinin açılışta başlamasına izin vermez). Uygulamayı açıp Başlat'a basman gerekir.
- **Arka plandayken uygulama açma kısıtlı:** Uygulama kapalıyken "YouTube'u aç" dersen Android doğrudan açtırmaz; JARVIS bildirim bırakır, dokununca açılır. Uygulama ekrandayken doğrudan açılır.
- **Kilitliyken** uygulama açma, ayarlar ve alarm komutları reddedilir; saat, pil, hava, fener, ses çalışır.
- **Uyandırma kelimesi** Android'in konuşma tanıma servisiyle yakalanır (ayrı bir hotword motoru yok). Çevrimdışı Türkçe paket yüklü değilse ses Google'ın servisine gidebilir; uygulama ses kaydetmez/saklamaz. Bazı telefonlarda tanıma yeniden başlarken kısa bip sesi gelebilir.
- **Anahtarsız yapay zekâ:** Ayarlar'daki "Ücretsiz yapay zekâ" açıkken komutlara uymayan sorular üçüncü taraf ücretsiz bir servise (Pollinations) metin olarak gider. Bu ChatGPT değildir; servis anahtar isteyebilir, yavaşlayabilir ya da kapanabilir, bunu bu ortamda doğrulayamadım.
- **ChatGPT (isteğe bağlı):** Ayarlar'a OpenAI API anahtarını girersen, yerleşik komutlara uymayan her şey ChatGPT'ye sorulur ve cevap sesli okunur (anahtar yoksa basit hazır cevaplar kullanılır). API anahtarı ChatGPT aboneliğinden ayrıdır ve kullanıma göre ücretlidir (platform.openai.com). Anahtar yalnızca telefonda saklanır; OpenAI'a konuştuğunun yazıya dökülmüş metni gider, ses gitmez.
- **Alarm** saat uygulamasına istek olarak gönderilir; kurulduğunu saat uygulamasından kontrol et.
